
var testName, testLength; // variables to later be used for the name of the assessment and the number of minutes the user has to complete the assessment

var questionArray = ["Which answer is correct? Pick one: (hint - it's C!)", "m", "Answer C!", "Answer A!", "Answer B!", "Answer C!", "Answer D!"]
/* populate the array with the content of one question in this format:
   Question text, question type (m for multiple choice, t for true/false, f for fill in the blank), the correct answer, and then up to four possible answers */

function populateQuestion1() {
	document.getElementById("question1").innerHTML = questionArray[0];
	document.getElementById("q1_1").innerHTML = questionArray[3];
	document.getElementById("q1_2").innerHTML = questionArray[4];
	document.getElementById("q1_3").innerHTML = questionArray[5];
	document.getElementById("q1_4").innerHTML = questionArray[6];
	// on page load, populate the question text and the four possible answers for question 1
}

/* placeholder for populating question 2 (true or false)
function populateQuestion2() {
	document.getElementById("question2").innerHTML = questionArray[...];
	document.getElementById("q2_0").innerHTML = questionArray[...];
	document.getElementById("q2_1").innerHTML = questionArray[...];
} */

function checkQuestion1() { // validate the user's selection for question 1
	if (document.getElementById("qInput1_3").checked) { // get the "checked" value for the input
		alert("Question 1 is correct."); // display a message that the question is correct if the correct answer is celected
	}
	else {
		alert("Question 1 is incorrect."); // display a message that the question is incorect if the incorrect answer or no answer is selected
	}
}


